//
//  AppDelegate.h
//  WLZ_ShoppingCart
//
//  Created by lijiarui on 15/12/10.
//  Copyright © 2015年 lijiarui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

