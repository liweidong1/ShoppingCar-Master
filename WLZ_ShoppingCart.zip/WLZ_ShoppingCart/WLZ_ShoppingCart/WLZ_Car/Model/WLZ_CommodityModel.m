//
//  WLZ_CommodityModel.m
//  WLZ_ShoppingCart
//
//  Created by lijiarui on 15/12/14.
//  Copyright © 2015年 lijiarui. All rights reserved.
//

#import "WLZ_CommodityModel.h"

@implementation WLZ_CommodityModel

@end
