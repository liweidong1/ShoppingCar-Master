//
//  WLZ_ShoppingCarController.h
//  WLZ_ShoppingCart
//
//  Created by lijiarui on 15/12/14.
//  Copyright © 2015年 lijiarui. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "WLZ_ShoppIngCarModel.h"
#import "WLZ_ShopViewModel.h"

#import "UIColor+WLZ_HexRGB.h"

#import "WLZ_ShoppingCarCell.h"
#import "WLZ_ShoppingCartEndView.h"
@interface WLZ_ShoppingCarController : UIViewController
#define APPScreenHeight [[UIScreen mainScreen] bounds].size.height
#define APPScreenWidth [[UIScreen mainScreen] bounds].size.width
@end
