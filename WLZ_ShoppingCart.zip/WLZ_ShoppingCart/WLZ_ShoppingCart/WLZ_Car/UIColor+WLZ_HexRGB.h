//
//  UIColor+WLZ_HexRGB.h
//  WLZ_ShoppingCart
//
//  Created by lijiarui on 15/12/14.
//  Copyright © 2015年 lijiarui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (WLZ_HexRGB)

+ (UIColor *)colorFromHexRGB:(NSString *)inColorString;
@end
